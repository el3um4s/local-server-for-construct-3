"use strict";

{
	C3.Plugins.MyCompany_DOMPlugin.Acts =
	{
		SetText(text)
		{
			if (this._text === text)
				return;		// no change
			
			// Update the locally stored text, and call UpdateElementState().
			// This calls GetElementState() - which contains the button text as part of the state -
			// and then calls UpdateState() in domSide.js with the state object, where the button text
			// is applied to the DOM element.
			this._text = text;
			this.UpdateElementState();
		}
	};
}