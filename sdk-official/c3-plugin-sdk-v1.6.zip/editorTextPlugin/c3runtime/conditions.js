"use strict";

{
	C3.Plugins.MyCompany_TextPlugin.Cnds =
	{
		IsLargeNumber(number)
		{
			return number > 100;
		}
	};
}