"use strict";

{
	C3.Plugins.MyCompany_TextPlugin.Type = class MyTextType extends C3.SDKTypeBase
	{
		constructor(objectClass)
		{
			super(objectClass);
		}
		
		Release()
		{
			super.Release();
		}
		
		OnCreate()
		{
		}
	};
}