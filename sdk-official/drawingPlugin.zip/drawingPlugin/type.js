"use strict";

{
	const PLUGIN_CLASS = SDK.Plugins.MyCompany_DrawingPlugin;
	
	PLUGIN_CLASS.Type = class MyDrawingPluginType extends SDK.ITypeBase
	{
		constructor(sdkPlugin, iObjectType)
		{
			super(sdkPlugin, iObjectType);
		}
	};
}