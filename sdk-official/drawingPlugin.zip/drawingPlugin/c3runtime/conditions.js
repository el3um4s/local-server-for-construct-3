"use strict";

{
	C3.Plugins.MyCompany_DrawingPlugin.Cnds =
	{
		IsLargeNumber(number)
		{
			return number > 100;
		}
	};
}