"use strict";

{
	C3.Plugins.MyCompany_DrawingPlugin.Acts =
	{
		Alert()
		{
			alert("Test property = " + this._testProperty);
		}
	};
}