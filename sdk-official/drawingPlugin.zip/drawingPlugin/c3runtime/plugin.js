"use strict";

{
	C3.Plugins.MyCompany_DrawingPlugin = class DrawingPlugin extends C3.SDKPluginBase
	{
		constructor(opts)
		{
			super(opts);
		}
		
		Release()
		{
			super.Release();
		}
	};
}