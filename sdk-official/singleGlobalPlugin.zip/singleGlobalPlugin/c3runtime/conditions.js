"use strict";

{
	C3.Plugins.MyCompany_SingleGlobal.Cnds =
	{
		IsLargeNumber(number)
		{
			return number > 100;
		}
	};
}