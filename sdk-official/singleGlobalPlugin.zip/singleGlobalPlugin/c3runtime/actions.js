"use strict";

{
	C3.Plugins.MyCompany_SingleGlobal.Acts =
	{
		Alert()
		{
			alert("Test property = " + this._testProperty);
		}
	};
}