"use strict";

{
	C3.Plugins.MyCompany_CustomImporter.Acts =
	{
		Alert()
		{
			alert("Test property = " + this._testProperty);
		}
	};
}