"use strict";

{
	C3.Behaviors.MyCompany_MyBehavior.Acts =
	{
		Stop()
		{
			// placeholder
		}
	};
}