"use strict";

{
	C3.Plugins.MyCompany_TextPlugin.Exps =
	{
		Double(number)
		{
			return number * 2;
		}
	};
	
}