"use strict";

{
	C3.Plugins.MyCompany_TextPlugin = class MyTextPlugin extends C3.SDKPluginBase
	{
		constructor(opts)
		{
			super(opts);
		}
		
		Release()
		{
			super.Release();
		}
	};
}